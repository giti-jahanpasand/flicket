# Flicket Todo List

## High

## Medium
* lock tickets after x number of days? This will have to be done via a Command function run as a crop job?

## Low
* add ability to filter tickets by who started them as well as who they're assigned to.
