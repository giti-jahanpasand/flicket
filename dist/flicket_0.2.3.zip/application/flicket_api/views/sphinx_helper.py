#! python3
# -*- coding: utf-8 -*-
#
# Flicket - copyright Paul Bourne: evereux@gmail.com

from application import app

api_url = "{}".format(app.config['FLICKET_API'])
